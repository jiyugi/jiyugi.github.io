くりひろいゲーム Version 0.2.2
著作者: ユウナリ <jiyugi@yahoo.com>

-------

『くりひろいゲーム』はWebブラウザーで動作するゲームです。
パソコンのマウスまたはモバイルのタッチパネルで遊べます。


## 遊び方

index.html をWebブラウザーで開いてください。
操作説明やルールはゲーム画面より下の部分に書いてあります。


## 内容物

background.png, sprite.png, title.png はゲームに必須の画像ファイルです。

kurihiroi.js はゲームのプログラムで、HTML にロードされると
特定のid を持った<canvas> 要素を検出してゲーム起動します。


## ゲームの転載について

このゲームは自由に転載できます。
以下のファイルをあなたのホームページにアップロードしてください。

  - background.png
  - index.html (リネーム可)
  - kurihiroi.css
  - kurihiroi.js
  - LICENSE.txt
  - sprite.png
  - title.png


## 更新履歴

Version 0.2.2:
  - README および著作権表示の修正
  - タイトル画面にバージョン情報を表示

Version 0.2.1:
  - 細かい表記の調整

Version 0.2.0:
  - マウスが画面外に移動してもゲームが止まらないように変更
  - プレイ画面のデザインを変更
  - CSS を分割
  - リファクタリング

Version 0.1.0:
  - 公開


-------

私のサイト『かなへびJS』には他にもゲームがあります。
良ければ遊んでみてください。

  https://jiyugi.github.io/

