// くりひろいゲーム, Version 0.2.2
// Copyright 2017, 2018 Yunari <jiyugi@yahoo.com>
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//  http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

(function() {
    "use strict";

    // 設定
    var config = {
        VERSION: "Version 0.2.2",
        ID_CANVAS: "js-kurihiroi-canvas",
        ID_BTN_RESET: "js-kurihiroi-btn-reset",
        URL_SPRITE: "sprite.png",
        URL_BACKGROUND: "background.png",
        URL_TITLE: "title.png"
    };

    // メッセージなどの文字列
    var strings = {
        SCORE: "Score",
        HIGHSCORE: "Highscore",
        COMBO: "hits!",
        GAMEOVER: "Game over!",
        PAUSE: "クリックで再開します"
    };

    // レベル定義
    // wait クリの落下する間隔
    // next 次レベルへ上がる得点
    // waitPlus 落下時間に加える乱数の最大値
    // どれもデフォルトは 0
    var levels = [{
        wait: 50,
        next: 100
    }, {
        wait: 30,
        next: 500
    }, {
        wait: 10,
        waitPlus: 40,
        next: 2500
    }, {
        waitPlus: 50
    }];


    // ゲームキャラ共通オブジェクト
    // 座標といくつかの定数と当たり判定処理を持つ
    function makeGamechar(spec) {
        var RADIUS = spec.RADIUS;
        var HEIGHT = spec.HEIGHT;
        var that = null;

        that = {

            // 定数

            RADIUS: RADIUS,
            HEIGHT: HEIGHT,

            // 座標

            x: spec.x,
            y: spec.y,

            // 座標を加算する
            move: function(dx, dy) {
                that.x += dx;
                that.y += dy;
            },

            // 他のゲームキャラと降れているか？
            isHitGamechar: function(gc) {
                return (
                    (Math.abs(that.x - gc.x) < RADIUS + gc.RADIUS) &&
                    (that.y >= gc.y - gc.HEIGHT && that.y - HEIGHT <= gc.y)
                );
            }
        };

        return that;
    }


    // プレイヤーオブジェクト
    function makePlayer(spec) {
        var RADIUS = 12;

        var that = makeGamechar({
            x: spec.x,
            y: spec.y,
            RADIUS: RADIUS,
            HEIGHT: 24
        });

        var direction = -1; // 向きを -1 か 1 で示す
        var distance = 0; // 移動先との距離
        var walkingTime = 0; // 歩いている時 1以上になる
        var alive = true;

        // 歩く
        function walk(distance) {
            var SPEED = 4;
            var destination = that.x + distance; // 移動先

            direction = (distance > 0)
                ? 1
                : -1;

            that.move(SPEED * direction, 0);

            // 移動先を越してしまわないように、
            // 向きによって別の関数で座標をクリップする
            that.x = (
                Math[
                    (direction > 0)
                        ? "min"
                        : "max"
                ](that.x, destination)
            );
        }

        // 更新
        that.update = function() {

            if (alive && distance !== 0) {
                walk(distance);
                distance = 0;
                walkingTime += 1;
            } else {
                walkingTime = 0;
            }
        };

        // 表示
        that.render = function(g) {

            var sx = (alive)
                ? (walkingTime === 0)
                    ? 0
                    : 1 + Math.floor(walkingTime / 2) % 2
                : 3;

            var sy = 1;
            var dx = that.x - 16;
            var dy = that.y - 32;

            g.drawSprite(g.ctx, sx, sy, dx, dy, direction);
        };

        // 歩き先を指定する
        that.walkTo = function(destination) {
            distance = destination - that.x;
        };

        // ダメージを与える
        that.onDamage = function() {
            alive = false;
        };

        // 指定範囲内におさめる
        that.clipPosition = function(left, right) {
            var x = that.x;

            x = Math.max(x, left + RADIUS);
            x = Math.min(x, right - RADIUS);
            that.x = x;
        };

        // 生きているか？
        that.isAlive = function() {
            return alive;
        };

        return that;
    }


    // 敵キャラオブジェクト
    function makeEnemy(spec) {
        var that = makeGamechar({
            x: spec.x,
            y: spec.y,
            RADIUS: 13,
            HEIGHT: 1
        });

        var vy = -2; // Y軸 移動量
        var opened = false; // 殻が割れている時 true になる
        var hitstop = 0; // 0 より大きい間、地面でストップする
        var ttl = 100; // 0 になると消える
        var alive = true;

        // ヒットストップ
        function doHitstop() {
            var BOUNCE = -14;

            vy = 0;
            hitstop -= 1;

            if (hitstop <= 0) {
                opened = true;
                vy = BOUNCE;
            }
        }

        // フェードアウト
        function feedout() {
            ttl -= 1;
            alive = ttl > 0;
        }

        // 更新
        that.update = function() {
            var MAX_FALL = 16;

            vy = Math.min(vy + 1, MAX_FALL);

            if (hitstop > 0) {
                doHitstop();
            }

            if (alive && opened) {
                feedout();
            }

            that.move(0, vy);
        };

        // 表示
        that.render = function(g) {
            var FEEDOUT_F = 20; // フェードアウトし始める生存時間

            var sx = (opened)
                ? 2 + Math.floor(ttl / 2) % 2
                : (hitstop > 0)
                    ? 1
                    : 0;

            var sy = 0;
            var dx = that.x - 16;
            var dy = that.y - 32;

            g.ctx.save();

            // 生存時間が一定以下ならフェードアウトさせる
            g.ctx.globalAlpha = (ttl <= FEEDOUT_F)
                ? ttl / FEEDOUT_F
                : 1;

            g.drawSprite(g.ctx, sx, sy, dx, dy);
            g.ctx.restore();
        };

        // 地面との接触
        that.onGround = function(bottom) {
            var STOP_F = 4; // ストップするフレーム数

            if (that.y >= bottom) {
                that.y = bottom;

                // 殻が割れる時、地面でストップする
                if (!opened && hitstop === 0) {
                    hitstop = STOP_F;
                }
            }
        };

        // キャッチされる
        that.onCatched = function() {
            alive = false;
        };

        // 生きてるか？
        that.isAlive = function() {
            return alive;
        };

        // 拾えるか？
        that.canCatch = function() {
            return opened;
        };

        // 落下中か？
        that.isFall = function() {
            return vy >= 0;
        };

        return that;
    }


    // 乱数生成関数を返す
    function makeGetRandom(spec) {
        var RANGE = spec.range; // 乱数の幅
        var RECORD = spec.rec; // 記録する数
        var history = [];

        if (RANGE < RECORD) {
            throw new Error("kueihieoi: ramge < record");
        }

        // 履歴とかぶらない乱数を作る
        function generate() {
            var ret = Math.floor(RANGE * Math.random());
            var i;

            // 求めた関数が過去のものとかぶっていたら、
            // 処理をやり直す
            for (i = 0; i < history.length; i += 1) {

                if (ret === history[i]) {
                    return generate();
                }
            }

            return ret;
        }

        // 乱数を返し、履歴を記録する
        return function() {
            var ret = generate();

            history.push(ret);

            if (history.length > RECORD) {
                history.shift();
            }

            return ret;
        };
    }


    // コンボ管理オブジェクト
    function makeCombo() {
        var TIME_MAX = 30;
        var time = 0;
        var combo = 0;

        return {

            // 更新。一定時間経つとコンボ数0
            update: function() {
                time -= 1;

                if (time <= 0) {
                    time = 0;
                    combo = 0;
                }
            },

            // コンボ数を表示する
            render: function(g) {
                g.ctx.save();
                g.ctx.font = "32px sans-serif";
                g.ctx.textBaseline = "top";
                g.ctx.fillStyle = "#ffc";
                g.ctx.textAlign = "right";
                g.ctx.globalAlpha = time / TIME_MAX;
                g.ctx.fillText(combo + " " + strings.COMBO, 320 - 16, 8);
                g.ctx.restore();
            },

            // コンボ数を返す
            get: function() {
                return combo;
            },

            // コンボを増やす
            add: function() {
                combo += 1;
                time = TIME_MAX;
            }
        };
    }


    // ゲーム画面オブジェクト
    function makeGame(levelList) {
        var LEFT = 48; // 床の左端
        var RIGHT = 320 - LEFT; // 床の右端
        var GROUND = 320 - 48; // 床の位置
        var EN_RANGE = 7; // 敵の出現範囲の細かさ
        var EN_MAX = 5; // 敵の数 

        var player = makePlayer({
            x: (LEFT + RIGHT) / 2,
            y: GROUND
        });

        var enemies = [];
        var enWait = 30;
        var combo = makeCombo();
        var score = 0;
        var falls = 0;
        var gameover = 0; // プレイヤーがミスするとカウントアップする

        // レベル定義
        var levels = levelList.slice();
        var level = levels.shift();

        // 乱数を返す関数
        var getRandom = makeGetRandom({
            range: EN_RANGE,
            rec: EN_MAX
        });

        // 次のレベルが存在するか？
        function hasNextLevel() {
            return levels.length > 0 && typeof level.next === "number";
        }

        // レベルを上げる
        function addLevel() {
            level = levels.shift();
            enWait = 20 * 5;
        }

        // プレイヤーを動かす
        function updatePlayer(pl, cursor) {

            if (cursor.tapping) {
                pl.walkTo(cursor.x);
            }

            pl.update();
            pl.clipPosition(LEFT, RIGHT);
        }

        // 敵 1体を動かす
        function updateEnemy(en) {
            en.update();
            en.onGround(GROUND);
        }

        // 敵とプレイヤーの接触
        function hitEnemyPlayer(en, pl) {
            var BASE = 10; // 基本スコア
            var BONUS = 5; // コンボによる増分

            if (en.isFall() && pl.isAlive() && pl.isHitGamechar(en)) {

                if (en.canCatch()) {
                    en.onCatched();
                    score += BASE + combo.get() * BONUS;
                    combo.add();
                } else {
                    pl.onDamage();
                }
            }
        }

        // 敵を出現させる
        function encountEnemy(enemies) {
            var RANGE = RIGHT - LEFT;
            var TOP = 64;
            var DOWN = 160;
            var INTERVAL = 10; // 落下位置を下げる個数の基準
            var INC = 8; // 落下位置の下がる量

            enemies.push(makeEnemy({
                x: LEFT + getRandom() / (EN_RANGE - 1) * RANGE,
                y: Math.min(TOP + Math.floor(falls / INTERVAL) * INC, DOWN)
            }));
        }

        // 更新
        function update(args) {

            if (!player.isAlive()) {
                gameover += 1;
            }

            combo.update();
            updatePlayer(player, args.cursor);

            // 消えた敵は配列から削除される
            enemies = enemies.filter(function(en) {
                updateEnemy(en);
                hitEnemyPlayer(en, player);

                return en.isAlive();
            });

            enWait -= 1; // 敵キャラ出現待ち

            if (player.isAlive() && enWait <= 0) {

                if (enemies.length < EN_MAX) {
                    encountEnemy(enemies);
                    falls += 1;
                }

                // 次の敵を待つ時間は、レベルに応じて変動する

                enWait = (level.wait > 0)
                    ? level.wait
                    : 0;

                if (level.waitPlus > 0) {
                    enWait += Math.random() * level.waitPlus;
                }
            }

            if (hasNextLevel() && score >= level.next) {
                addLevel();
            }
        }

        // ゲームオーバーを表示
        function renderGameover(ctx, gameover) {

            if (gameover % 20 < 10 || gameover >= 40) {
                ctx.save();
                ctx.font = "32px sans-serif";
                ctx.textAlign = "center";
                ctx.textBaseline = "middle";
                ctx.fillStyle = "#fff";
                ctx.fillText(strings.GAMEOVER, 160, 160);
                ctx.restore();
            }
        }

        // 表示
        function render(g) {

            // 背景とキャラクター

            g.ctx.drawImage(g.imgLoader.getImage("background"), 0, 0);
            player.render(g);

            enemies.forEach(function(en) {
                en.render(g);
            });

            // スコア

            g.ctx.save();
            g.ctx.font = "bold 16px sans-serif";
            g.ctx.textBaseline = "top";
            g.ctx.fillStyle = "#fff";
            g.ctx.fillText(strings.SCORE + " " + score, 16, 16);
            g.ctx.restore();

            // トースト類

            if (combo.get() >= 2) {
                combo.render(g);
            }

            if (!player.isAlive()) {
                renderGameover(g.ctx, gameover);
            }
        }

        return {

            // ゲームオーバーか？
            isEnd: function() {
                var RETRYING_TIME = 40;

                return gameover >= RETRYING_TIME;
            },

            getScore: function() {
                return score;
            },

            update: update,
            render: render,
            isAlive: player.isAlive
        };
    }


    // メインオブジェクト
    function makeMain() {
        var modeName = "title";
        var paused = false;
        var highscore = 0;
        var game = null;

        // タイトルへ遷移する
        function gotoTitle() {
            modeName = "title";

            if (game) {
                highscore = Math.max(game.getScore(), highscore);
            }
        }

        // ゲームを開始する
        function gotoGame() {
            game = makeGame(levels);
            modeName = "game";
            paused = false;
        }

        // ポーズする
        function setPause() {
            paused = true;
        }

        // ハイスコアを表示する
        function renderHighscore(ctx, highscore) {
            ctx.save();
            ctx.font = "bold 16px sans-serif";
            ctx.textBaseline = "top";
            ctx.fillStyle = "#966";
            ctx.fillText(strings.HIGHSCORE + " " + highscore, 16, 16);
            ctx.restore();
        }

        // バージョン情報を表示する
        function renderVersion(ctx) {
            ctx.save();
            ctx.font = "bold 16px sans-serif";
            ctx.textBaseline = "top";
            ctx.textAlign = "right";
            ctx.fillStyle = "#966";
            ctx.fillText(config.VERSION, 320 - 16, 16);
            ctx.restore();
        }

        // ポーズ画面を表示する
        function renderPause(ctx) {
            ctx.save();
            ctx.fillStyle = "rgba(0, 0, 0, 0.4)";
            ctx.fillRect(0, 0, 320, 320);
            ctx.font = "32px sans-serif";
            ctx.textBaseline = "middle";
            ctx.textAlign = "center";
            ctx.fillStyle = "#fff";
            ctx.fillText(strings.PAUSE, 160, 160);
            ctx.restore();
        }

        // モード別の動作
        var mode = {

            title: function(g, cursor) {

                g.ctx.drawImage(g.imgLoader.getImage("title"), 0, 0);
                renderVersion(g.ctx);

                if (highscore > 0) {
                    renderHighscore(g.ctx, highscore);
                }

                if (cursor.clicked) {
                    gotoGame();
                }
            },

            game: function(g, cursor) {

                if (paused) {
                    paused = !cursor.clicked;
                } else {
                    game.update({
                        cursor: cursor
                    });
                }

                game.render(g);

                if (paused) {
                    renderPause(g.ctx);
                }

                if (game.isEnd() && cursor.clicked) {
                    gotoTitle();
                }
            }
        };

        return {

            // タイマー割り込み 
            doTick: function(args) {
                mode[modeName](args.g, args.cursor);
            },

            // タイトル画面か？
            isTitle: function() {
                return modeName === "title";
            },

            gotoTitle: gotoTitle,
            setPause: setPause
        };
    }


    // スプライトを定義し、それを表示する関数を返す
    function makeSprite(spec) {
        var img = spec.img;
        var w = spec.width;
        var h = spec.height;

        // 表示関数
        return function(ctx, sx, sy, dx, dy, opt_mirror) {
            var x = Math.floor(dx);
            var y = Math.floor(dy);

            ctx.save();

            if (opt_mirror > 0) {
                ctx.scale(-1, 1);
                x = -(x + w);
            }

            ctx.drawImage(img, sx * w, sy * h, w, h, x, y, w, h);
            ctx.restore();
        };
    }


    // マウス・タッチパネルの抽象化を行い、
    // その状態を取得する関数を返す
    function makeCursorGetter(canvas) {
        var x = 0;
        var y = 0;
        var tapping = false; // ボタンが押されて入れば true
        var swClicked = false;
        var idTouch = -1;

        // マウスの状態を更新する。
        function updateCursor(layerX, layerY) {
            x = Math.floor(layerX);
            y = Math.floor(layerY);
        }

        // クライアント上の座標を下にマウスの状態を更新する。
        // CSS により大きさが変更された場合も考慮する
        function moveClient(clientX, clientY) {
            var bcr = canvas.getBoundingClientRect();
            var scale = canvas.width / bcr.width;

            updateCursor(
                (clientX - bcr.left) * scale,
                (clientY - bcr.top) * scale
            );
        }

        // 指定ID の Touch オブジェクトがあれば返す
        function getTouch(e, id) {
            return ([].filter.call(e.changedTouches, function(o) {
                return o.identifier === id;
            })[0] || null);
        }

        // マウスイベント

        document.addEventListener("mousemove", function(e) {

            if (tapping) {
                e.preventDefault();
            }

            moveClient(e.clientX, e.clientY);
        }, false);

        canvas.addEventListener("mousedown", function(e) {
            e.preventDefault();

            if (e.button === 0) {
                tapping = true;
            }
        }, false);

        document.addEventListener("mouseup", function(e) {

            if (e.button === 0) {
                e.preventDefault();

                if (e.target === canvas) {
                    swClicked = tapping;
                }
                tapping = false;
            }
        }, false);

        // タッチイベント
        // 最新のタッチのみを監視する

        canvas.addEventListener("touchstart", function(e) {
            var tch = e.changedTouches[0];

            e.preventDefault();
            idTouch = tch.identifier;
            moveClient(tch.clientX, tch.clientY);
            tapping = true;
        }, false);

        canvas.addEventListener("touchmove", function(e) {
            var tch = getTouch(e, idTouch);

            e.preventDefault();

            if (tch) {
                moveClient(tch.clientX, tch.clientY);
            }
        }, false);

        canvas.addEventListener(["touchend"], function(e) {
            var tch = getTouch(e, idTouch);
            var rect = null;

            if (tch && tapping) {
                e.preventDefault();
                rect = canvas.getBoundingClientRect();

                if (
                    tch.clientX >= rect.left &&
                    tch.clientX <= rect.right &&
                    tch.clientY >= rect.top &&
                    tch.clientY <= rect.bottom
                ) {
                    swClicked = true;
                }

                tapping = false;
            }
        }, false);

        // 右クリックメニュー無効化
        canvas.addEventListener("contextmenu", function (e) {
            e.preventDefault();
        }, false);

        // 最新のカーソル状態を返す関数
        return function() {
            var clicked = swClicked;

            swClicked = false;

            return {
                x: x,
                y: y,
                tapping: tapping,
                clicked: clicked
            };
        };
    }


    // アニメーション開始
    function setAnimation(callback, delay) {
        var id = 0;

        function start() {

            if (id === 0) {
                id = setInterval(callback, delay);
            }
        }

        addEventListener("blur", function() {
            clearInterval(id);
            id = 0;
        }, false);

        addEventListener("focus", start, false);
        start();
    }


    // 画像ローダオブジェクト
    function makeImageLoader(list) {
        var images = {};

        Object.keys(list).forEach(function(i) {
            var img = new Image();

            img.src = list[i];
            images[i] = img;
        });

        return {

            // 画像を返す
            getImage: function(name) {
                return images[name] || null;
            },

            // ロードが全て終わっているか？
            hasLoadedAll: function() {
                var count= Object.keys(images).filter(function(i) {
                    return !images[i].complete;
                }).length;

                return count === 0;
            }
        };
    }


    // 初期化
    // ある id を持つ canvas 要素を検出し、ゲームを起動する
    function initGame() {
        var SLEEP_TIME = 50;

        var canvas = document.getElementById(config.ID_CANVAS);
        var btnReset = document.getElementById(config.ID_BTN_RESET);

        if (!canvas || typeof canvas.getContext !== "function") {
            throw new Error("kurihiroi: no canvas.");
        }

        var ctx = canvas.getContext("2d");
        var main = makeMain();

        // 画像をロードする
        var imgLoader = makeImageLoader({
            sprite: config.URL_SPRITE,
            background: config.URL_BACKGROUND,
            title: config.URL_TITLE
        });

        // カーソルの状態を返す関数
        var getCursor = makeCursorGetter(canvas);

        // スプライトを 1枚表示する関数
        var drawSprite = makeSprite({
            img: imgLoader.getImage("sprite"),
            width: 32,
            height: 32
        });

        // アニメーション割り込み
        function doTick() {

            if (!imgLoader.hasLoadedAll()) {
                return;
            }

            main.doTick({
                cursor: getCursor(),

                g: {
                    ctx: ctx,
                    imgLoader: imgLoader,
                    drawSprite: drawSprite
                }
            });
        }

        // 誤ったリロードを防止する
        addEventListener("beforeunload", function(e) {

            if (!main.isTitle()) {
                e.preventDefault();
            }
        }, false);

        // リセットボタン
        if (btnReset) {

            btnReset.addEventListener("click", function() {
                btnReset.blur();
                main.gotoTitle();
            }, false);
        }

        // 非アクティブ時にポーズさせる
        addEventListener("blur", function() {
            main.setPause();
            doTick();
        }, false);

        setAnimation(doTick, SLEEP_TIME);
    }

    initGame();
}());


