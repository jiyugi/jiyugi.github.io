魚すくいゲーム Version 1.2.1
作: ユウナリ <jiyugi@yahoo.com>


-------

『魚すくいゲーム』はWebブラウザーで動作するゲームです。
パソコンのマウスまたはモバイルのタッチパネルで遊べます。


## 遊び方

index.html をWebブラウザーで開いてください。
操作説明やルールはゲーム画面より下の部分に書いてあります。


## ゲームの転載について

このゲームは自由に転載できます。
以下のファイルをあなたのホームページにアップロードしてください。

  - data/ 内の全て
  - index.css
  - index.html (リネーム可)
  - jfish.css
  - jfish.js
  - LICENSE.txt
  - README.txt


## 著作権について

jfish.js はApache License, Version 2.0 の下に提供されています。
ライセンス全文はLICENSE.txt にあります。以下のURL に日本語訳があります。

  https://ja.osdn.net/projects/opensource/wiki/licenses%2FApache_License_2.0

その他全てのファイルはCC0 1.0 の下にパブリック・ドメイン提供されています。

  https://creativecommons.org/publicdomain/zero/1.0/deed.ja


## 更新履歴

Version 1.2.1:
  - README および著作権表示の修正
  - ポイの移動中にマウスが画面外に出た時の挙動を変更

Version 1.2.0:
  - ゲージの表示を変更
  - イラストから著作権表示を削除
  - CSS を分割
  - プログラムのフォーマットを修正

Version 1.1.0:
  - 魚の出現位置のばらつきを調整
  - タッチイベントを少し調整

Version 1.0.0:
  - 公開


------

私のサイト『かなへびJS』には他にもゲームがあります。
良ければ遊んでみてください。

  https://jiyugi.github.io/

